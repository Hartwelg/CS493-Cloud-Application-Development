loads = "loads"
boats = "boats"
owners = "owners"

# These should be copied from an OAuth2 Credential section at
# https://console.cloud.google.com/apis/credentials
client_id = r'129481253275-9n6e0157g581r24cr8l4ubu81j22otup.apps.googleusercontent.com'
client_secret = r'0mFZVvWZqS9zOA_Bax28Vq4T'