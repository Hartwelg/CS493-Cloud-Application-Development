
function init() {

    document.getElementById('js-message').innerHTML =
        gettext('Hello World from javascript!')
}


window.onload = init;
